from Bank import Bank


class Valid:
    # User Inputs
    name = ""
    password = ""
    amount = 0
    accounts = [];

    # Validating User Details
    @classmethod
    def validate(cls):
        # List for Storing Existing User Records

        customer1 = Bank("ASM", "Password@123", 1200)
        customer2 = Bank("Kavi", "Password@1234", 1100)
        customer3 = Bank("Ravi", "Password@123456", 1000)
        customer4 = Bank("Mahesh", "Password@123456", 1000)
        cls.accounts.append(customer1)
        cls.accounts.append(customer2)
        cls.accounts.append(customer3)
        cls.accounts.append(customer4)

        print("-------------------------------------------------")
        print("\n------------Welcome to ABC Bank-------------\nEnter to continue....\n1.LogIn\n2.Signup")
        print("-------------------------------------------------")
        print("-------------------------------------------------")
        userChoise = input();  # user input for LogIn or SignUp
        print("-------------------------------------------------")
        print("-------------------------------------------------")
        # LogIn
        if userChoise == "1":
            # Taking input from user
            try:
                print("-------------------------------------------------")
                print("Enter Username");
                cls.name = input();
                print("Enter Password")
                cls.password = input();
                print("-------------------------------------------------")
                print("-------------------------------------------------")

            except Exception:
                print("-------------------------------------------------")
                print("Error");
                print("-------------------------------------------------")
                cls.validate()

            # LogIn Validation for Checking Users in the List

            count = 0;
            for BankAccountDetails in cls.accounts:
                if cls.name == BankAccountDetails.getName() and cls.password == BankAccountDetails.getPassword():
                    print("Logged In Successfully")
                    count = 1;
                    BankAccountDetails.operation()

            if count == 0:
                print("-------------------------------------------------");
                print("Enter Valid Details");
                print("-------------------------------------------------");
                cls.validate();

        # signUp

        elif userChoise == "2":
            print("-------------------------------------------------");
            # Taking input from user

            try:
                print("Enter Username");
                cls.name = input();

                print("Enter Password");
                cls.password = input();

                print("Enter amount to deposit");
                cls.amount = int(input());

                newUser = Bank(cls.name, cls.password, cls.amount);
                cls.accounts.append(newUser);
                print("-------------------------------------------------")
                print("SignUp Successful")
                print("-------------------------------------------------")
                newUser.operation();
                print("-------------------------------------------------")


            except Exception:
                print("-------------------------------------------------");
                print("\nEnter Valid Details\n");
                print("-------------------------------------------------");
                cls.validate();

            finally:
                print("Done")

        else:
            print("-------------------------------------------------")
            print("\nInput Invalid\n")
            print("-------------------------------------------------")
            cls.validate()

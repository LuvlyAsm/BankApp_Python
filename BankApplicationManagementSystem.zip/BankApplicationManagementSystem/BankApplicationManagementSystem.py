"""

Title: Bank Application Management System

Author: Akbar Shameem Musthaq S

Created at:10-June-2022

Updated at: 13-June-2022

Reviewed by:Naveen Subramaniam

Reviewed at: 13-June-2022

"""

#Main Class
from Validation import Valid

validation = Valid()

validation.validate()
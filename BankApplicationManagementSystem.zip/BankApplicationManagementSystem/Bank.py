import Validation as val


class Bank:
    # User Variables
    name = ""
    password = ""
    amount = 0

    depositAmount = 0
    withdrawAmount = 0

    # List Transaction History
    transactionHistory = [];

    # constructor to assign user datas
    def __init__(self, name, password, amount):
        self.name = name
        self.password = password
        self.amount = amount

    # Encapsulation for getting username and password which is already present in the accounts
    def getName(self):
        return self.name

    def getPassword(self):
        return self.password

    # operations to be performed by user public

    def operation(self):

        print("-------------------------------------------------");
        print("Enter to Continue\n1.Deposit\n2.Withdraw\n3.Balance\n4.Transaction History\n5.LogOut\n");
        print("-------------------------------------------------");

        choise = int(input())
        if choise==1:
            self.deposit();
        elif choise==2:
            self.withdraw();
        elif choise==3:
            self.balance()
        elif choise==4:
            self.transaction()
        elif choise==5:
            self.logOut()
        else:
            print("Invalid Input")


    # Deposit money to bank account

    def deposit(self):

        print("Enter a Amount to be Deposit...:");
        self.depositAmount=0
        self.depositAmount = int(input());
        self.amount = self.amount + self.depositAmount;
        print("-------------------------------------------------");
        # Updating Transaction History
        print("After Deposit Account Balance is :" , self.amount);
        transHistory= "+" + str(self.depositAmount)
        self.transactionHistory.append(transHistory)
        print("-------------------------------------------------")
        self.operation();

    # Withdraw  money from bank account

    def withdraw(self):
        self.withdrawAmount=0
        print("-------------------------------------------------");
        print("Enter How Much You Want to Withdraw...");
        self.withdrawAmount = int(input());

    # Checking Bank Balance > Withdraw amount or not
        if (self.withdrawAmount <= self.amount):
            self.amount = self.amount - self.withdrawAmount;
            print("-------------------------------------------------");
            # Updating Transaction History
            print("Your Account Balance is : " , self.amount);
            transHistory = "-" + str(self.withdrawAmount)
            self.transactionHistory.append(transHistory)
            print("-------------------------------------------------");


        else:
            print("-------------------------------------------------");
            print("Insufficient Balance");
            print("-------------------------------------------------");
            print("Your Account Balance is : " , self.amount);
            print("-------------------------------------------------");
        self.operation();

    # Check Bank Balance

    def balance(self):
        print("Your Account Balance is : " , self.amount);
        print("-------------------------------------------------");
        self.operation();

    # View Transaction history

    def transaction(self):

        print("Your Transaction History is :");
        for i in range(0,len(self.transactionHistory)):
            print(self.transactionHistory[i]);
        print("-------------------------------------------------");
        self.operation();

    # User LogOut
    def logOut(self):
        print("Successfully Logged Out :)");
        print("-------------------------------------------------");
        val.Valid.validate()

        # calling by object creation
        '''m = val.Valid()
        val.Valid.validate(val.Valid())'''